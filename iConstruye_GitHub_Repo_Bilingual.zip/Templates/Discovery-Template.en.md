# Discovery Template (EN)
