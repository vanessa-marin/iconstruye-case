# Pitch – iConstruye – Ecosistema Digital Construcción (EN)
60–90 seconds pitch in English.
