# PRD – iConstruye – Ecosistema Digital Construcción (ES)
Requerimientos funcionales y no funcionales en español.
