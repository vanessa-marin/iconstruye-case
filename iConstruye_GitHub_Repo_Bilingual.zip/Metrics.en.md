# Metrics – iConstruye – Ecosistema Digital Construcción (EN)
North Star Metric and key KPIs for the product.
