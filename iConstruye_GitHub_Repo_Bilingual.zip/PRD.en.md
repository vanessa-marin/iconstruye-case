# PRD – iConstruye – Ecosistema Digital Construcción (EN)
Functional and non-functional requirements in English.
