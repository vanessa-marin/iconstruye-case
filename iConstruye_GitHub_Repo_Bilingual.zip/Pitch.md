# Pitch – iConstruye – Ecosistema Digital Construcción (ES)
Pitch de 60–90 segundos en español.
