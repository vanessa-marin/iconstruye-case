# Metrics – iConstruye – Ecosistema Digital Construcción (ES)
Métricas clave, NSM y KPIs definidos para el producto.
