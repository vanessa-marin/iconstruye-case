# Learnings – iConstruye – Ecosistema Digital Construcción (EN)
Key learnings from the project in English.
