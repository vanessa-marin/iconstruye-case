# Product Case – iConstruye – Ecosistema Digital Construcción (EN)
Full case description in English. Plataforma B2B para flujos de solicitud, aprobación y gestión de materiales en construcción.
