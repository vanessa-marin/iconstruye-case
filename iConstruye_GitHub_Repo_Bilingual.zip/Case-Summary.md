# Case Summary – iConstruye – Ecosistema Digital Construcción (ES)
Resumen ejecutivo del caso en español.
