# Case Summary – iConstruye – Ecosistema Digital Construcción (EN)
Executive summary of the case in English.
