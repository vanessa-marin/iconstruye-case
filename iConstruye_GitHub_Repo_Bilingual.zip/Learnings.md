# Learnings – iConstruye – Ecosistema Digital Construcción (ES)
Aprendizajes clave del proyecto en español.
